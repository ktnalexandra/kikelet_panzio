﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kikelet_panzio
{
    /// <summary>
    /// Interaction logic for UjUgyfelAblak.xaml
    /// </summary>
    public partial class UjUgyfelAblak : Window
    {
        public Ugyfel UjUgyfel { get; private set; }
        public UjUgyfelAblak()
        {
            InitializeComponent();
        }

        private void btn_UjUgyfel_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(tbx_Nev.Text) || string.IsNullOrEmpty(tbx_Email.Text) || dtp_Szul.SelectedDate == null)
            {
                MessageBox.Show("Kérjük az összes mezőt töltse ki!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            UjUgyfel = new Ugyfel
            {
                Nev = tbx_Nev.Text,
                SzulDatum = dtp_Szul.SelectedDate.Value,
                Email = tbx_Email.Text,
                VIP = chx_VIP.IsChecked ?? false,
                UgyfelAz = $"{tbx_Nev.Text}_{DateTime.Now:G}",
            };

            DialogResult = true;
            Close();
        }
    }
}
