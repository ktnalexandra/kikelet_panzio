﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kikelet_panzio
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        internal Adat adat;
        public MainWindow()
        {
            InitializeComponent();

            adat = new Adat();
            FrissitSzobak();
            FrissitUgyfelek();
            FrissitFoglalasok();
            FrissitStatisztikak();
        }

        private void FrissitSzobak()
        {
            lbx_Szobak.Items.Add(adat.szobak);
            foreach (var szoba in adat.szobak)
            {
                lbx_Szobak.Items.Add($"Szoba: {szoba.SzobaSzam}, Ferőhelyek: {szoba.FeroHelyekSzama}, Ár/fő: {szoba.ArPerFo} Ft");
            }
        }

        private void FrissitUgyfelek()
        {
            lbx_Ugyfelek.Items.Clear();
            foreach (var ugyfel in adat.ugyfelek)
            {
                lbx_Ugyfelek.Items.Add($"Ügyfél neve: {ugyfel.Nev}, Email: {ugyfel.Email}, VIP: {ugyfel.VIP}");
            }
        }

        private void FrissitFoglalasok()
        {
            lbx_Foglalasok.Items.Clear();
            foreach (var foglalas in adat.foglalasok)
            {
                lbx_Foglalasok.Items.Add(newItem: $"{foglalas.Vendeg.Nev}, Szoba: {foglalas.Panzio.SzobaSzam}, Érkezés: {foglalas.ErkezesDatuma}, Távozás: {foglalas.TavozasDatuma}, Létszám: {foglalas.Letszam}, Állapot:{foglalas.Allapot}, Összes ár: {foglalas.OsszAr} Ft");
            }
            lbx_Foglalasok.ItemsSource = adat.foglalasok;
        }

        private void FrissitStatisztikak()
        {
            txb_OsszBevetel.Text = adat.OsszBevetel().ToString() + "Ft";
            var LegtobbetKivettSzoba = adat.LegtobbetKivettSzoba();
            txb_LegtobbetKivett.Text = LegtobbetKivettSzoba != null ? LegtobbetKivettSzoba.SzobaSzam.ToString() : "Nincs adat";

            lbx_Ugyfelek.Items.Clear();
            foreach (var ugyfel in adat.VisszajaroUgyfelek())
            {
                lbx_Ugyfelek.Items.Add($"Ügyfél neve: {ugyfel.Nev}, Email: {ugyfel.Email}");
            }
        }

        private void btn_UgyfelFelvetele_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new UjUgyfelAblak();
            if (dialog.ShowDialog() == true)
            {
                adat.ugyfelek.Add(dialog.UjUgyfel);
                FrissitUgyfelek();
            }
        }

        private void btn_FoglalasFelvete_Click(object sender, RoutedEventArgs e)
        {
            var dialog2 = new UjFoglalasAblak(adat.szobak, adat.ugyfelek);
            if (dialog2.ShowDialog() == true)
            {
                adat.foglalasok.Add(dialog2.UjFoglalas);
                FrissitFoglalasok();
                FrissitStatisztikak();
            }
        }
    }
}
