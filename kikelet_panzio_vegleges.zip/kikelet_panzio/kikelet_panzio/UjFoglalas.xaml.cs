﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kikelet_panzio
{
    /// <summary>
    /// Interaction logic for UjFoglalasAblak.xaml
    /// </summary>
    public partial class UjFoglalasAblak : Window
    {
        internal Foglalas UjFoglalas { get; private set; }
        public UjFoglalasAblak(List<Szoba> szobak, List<Ugyfel> ugyfelek)
        {
            InitializeComponent();

            cbx_Szoba.ItemsSource = szobak;
            cbx_Ugyfel.ItemsSource = ugyfelek;
        }

        private void btn_UjFoglalas_Click(object sender, RoutedEventArgs e)
        {
            if (cbx_Szoba.SelectedItem == null || cbx_Ugyfel.SelectedItem == null || !DateTime.TryParse(dtp_Erkezes.Text, out var erkezes) || !DateTime.TryParse(dtp_Tavozas.Text, out var tavozas) || !int.TryParse(tbx_Letszam.Text, out var letszam))
            {
                MessageBox.Show("Kérjük az összes mezőt töltse ki!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            int letszam2;
            if (!int.TryParse(tbx_Letszam.Text, out letszam2))
            {
                MessageBox.Show("Kérjük érvényes létszámot adjon meg", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var szoba = (Szoba)cbx_Szoba.SelectedItem;
            var ugyfel = (Ugyfel)cbx_Ugyfel.SelectedItem;
            var erkezesDatum = dtp_Erkezes.SelectedDate.Value;
            var tavozasDatum = dtp_Tavozas.SelectedDate.Value;

            if (tavozasDatum <= erkezesDatum)
            {
                MessageBox.Show("A távozás dátuma nem lehet korábbi vagy ugyanaz, mint az érkezés dátuma!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var napokSzama = (tavozasDatum - erkezesDatum).Days;
            var osszesAr = napokSzama * szoba.arPerFo * letszam2;
            if (ugyfel.VIP)
            {
                //osszesAr *= 0.97;
            }

            UjFoglalas = new Foglalas
            {
                Panzio = szoba,
                Vendeg = ugyfel,
                ErkezesDatuma = erkezes,
                TavozasDatuma = tavozas,
                Letszam = letszam,
                OsszAr = osszesAr,
                Allapot = "Előjegyzett",
            };

            DialogResult = true;
            Close();
        }
    }
}
